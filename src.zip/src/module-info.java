module NeuralNetwork {
    requires neuroph.core;
}